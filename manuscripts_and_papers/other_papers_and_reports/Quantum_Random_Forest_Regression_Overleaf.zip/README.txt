========================================================================
SPRINGER NATURE JOURNAL SUBMISSION PACKAGE
========================================================================
Article Title:
Qubit-Compressed Quantum Random Forest Regression on NISQ Processors

Authors:
- Madhira Venkata Ramesh Reddy (ramesh_madhira@srmap.edu.in)
- Suresh Aala (suresh_aala@srmap.edu.in)
- Varsha Sambhaje (varsha.s@srmap.edu.in)
Affiliation:
Department of Computer Science and Engineering,
SRM University-AP, Amaravati, Andhra Pradesh, India

Template: Official Springer Nature Template (sn-jnl.cls)
Documentclass: \documentclass[sn-mathphys,Numbered]{sn-jnl}
Bibliography: sn-mathphys.bst with references.bib

HOW TO COMPILE ON OVERLEAF:
1. Log in to your Overleaf account (https://www.overleaf.com).
2. Click 'New Project' -> 'Upload Project'.
3. Select this ZIP file ('Springer_Nature_Overleaf_Package.zip').
4. In Overleaf Settings (top-left menu):
   - Compiler: pdfLaTeX (or LaTeX / XeLaTeX)
   - TeX Live version: 2023 or later
   - Main document: main.tex
5. Click 'Recompile'.
========================================================================
